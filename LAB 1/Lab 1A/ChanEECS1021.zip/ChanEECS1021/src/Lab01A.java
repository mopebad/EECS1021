public class Lab01A {
    public static void main (String[] args) {


        int stdNum  = 222272447;
        int remainder = stdNum % 1021;
        System.out.println("My name is Joshua Chan.");
        System.out.println("My student number is 222272447.");
        System.out.println("The remainder of my student number divided by 1021 is " + remainder + ".");
    }
}